@echo off
cd /d "C:\Users\Acer\Desktop\RFD"
RFD-windows-latest.exe player --user_code Pumpkin:3

pause